var PMA_gotoWhitelist = new Array();
